//
//  ViewController.swift
//  test-1
//
//  Created by Karam Sakallah on 9/27/16.
//  Copyright © 2016 Karam Sakallah. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var captureSession = AVCaptureSession()
    var sessionOutput = AVCaptureStillImageOutput()
    var previewLayer = AVCaptureVideoPreviewLayer()

    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var img: UIImageView!
    
    
    var rotateNum = 0
    
    
    @IBAction func alphaSlider(sender: UISlider) {
        let alphaValue = sender.value

        img.alpha = CGFloat(alphaValue)
    }
    
    
    @IBAction func menuClicked(sender: UIButton) {
        let controller = UIAlertController(title: "Options",message:nil, preferredStyle: .ActionSheet)
        
        let libraryAction = UIAlertAction(title: "Choose from library",style: .Default, handler: nil)
        let takePhotoAction = UIAlertAction(title: "Take a photo",style: .Default, handler: nil)
        let aboutAction = UIAlertAction(title: "About", style: .Default, handler: nil)
        let cancelAction = UIAlertAction(title: "Back", style: .Cancel, handler: nil)
        
        
        controller.addAction(libraryAction)
        controller.addAction(takePhotoAction)
        controller.addAction(aboutAction)
        controller.addAction(cancelAction)
        
        if let ppc = controller.popoverPresentationController {
            ppc.sourceView = sender
            ppc.sourceRect = sender.bounds
        }
        presentViewController(controller, animated: true, completion: nil)
    }
    
    @IBAction func rotateClicked(sender: UIButton) {
        switch(rotateNum){
            case 0:
                print("0")
                UIView.animateWithDuration(1.0, animations: {
                    self.img.transform = CGAffineTransformMakeRotation((90.0 * CGFloat(M_PI)) / 180.0)
                })
                break
            case 1:
                UIView.animateWithDuration(1.0, animations: {
                    self.img.transform = CGAffineTransformMakeRotation((180.0 * CGFloat(M_PI)) / 180.0)
                })
                break
            case 2:
                UIView.animateWithDuration(1.0, animations: {
                    self.img.transform = CGAffineTransformMakeRotation((270.0 * CGFloat(M_PI)) / 180.0)
                })
                break
            case 3:
                UIView.animateWithDuration(1.0, animations: {
                    self.img.transform = CGAffineTransformMakeRotation((360.0 * CGFloat(M_PI)) / 180.0)
                })
                break
            default:
                print("default")
        }
        
        rotateNum += 1
        if rotateNum == 4 { rotateNum = 0 }
    }
    
    override func viewWillAppear(animated: Bool) {
                
        let devices = AVCaptureDevice.devicesWithMediaType(AVMediaTypeVideo)
        
        for device in devices {
            if device.position == AVCaptureDevicePosition.Back {
                
                do {
                    let input = try AVCaptureDeviceInput(device: device as! AVCaptureDevice)
                    
                    if captureSession.canAddInput(input){
                        captureSession.addInput(input)
                        
                        sessionOutput.outputSettings = [AVVideoCodecKey: AVVideoCodecJPEG]
                        
                        if captureSession.canAddOutput(sessionOutput) {
                            captureSession.addOutput(sessionOutput)
                            captureSession.startRunning()
                        
                            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
                            previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
                            previewLayer.connection.videoOrientation = AVCaptureVideoOrientation.Portrait
                        
                            cameraView.layer.addSublayer(previewLayer)
                        
                            previewLayer.position = CGPoint(x: self.cameraView.frame.width/2, y: self.cameraView.frame.height/2)
                            previewLayer.bounds = cameraView.frame
                        }
                    }
                }
                catch {
                    print("ERROR")
                }
                
            }
        }
        
    }


}

